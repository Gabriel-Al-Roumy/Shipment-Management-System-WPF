﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShipmentManagementSystem.Models
{
    public class Address
    {
        [MaxLength(100)]
        public string Street { get; set; }
        [MaxLength(50)]
        public string City { get; set; }
        [MaxLength(10)]
        public string ZipCode { get; set; }
        [MaxLength(50)]
        public string Country { get; set; }

        public Address() { }

        public Address(
            string street,
            string city,
            string zipCode,
            string country)
        {
            Street = street;
            City = city;
            ZipCode = zipCode;
            Country = country;
        }

    }
}
