﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ShipmentManagementSystem.Models.Enums;

namespace ShipmentManagementSystem.Models
{
    public class Shipment
    {
        public int ShipmentId { get; set; }
        [Required]
        [MaxLength(100)]
        public string SenderName { get; set; }
        [Required]
        [MaxLength(100)]
        public string RecipientName { get; set; }
        public Address DestinationAddress { get; set; }
        public DateTime ShipmentDate { get; set; } = DateTime.Now;
        public DateTime ExpectedDeliveryDate { get; set; }
        [Column(TypeName = "decimal(18,2)")]
        public decimal ShipmentWeight { get; set; }
        [Column(TypeName = "decimal(18,2)")]
        public decimal ShippingCost { get; set; }
        public ShipmentStatus Status { get; set; }
        [MaxLength(50)]
        public string TrackingNumber { get; set; }
        [MaxLength(100)]
        public string CourierCompany { get; set; }

        public Shipment () {
        }
        public Shipment(string senderName,string recipientName,Address destinationAddress,DateTime shipmentDate,DateTime expectedDeliveryDate,decimal shipmentWeight,decimal shippingCost,ShipmentStatus status,string trackingNumber,string courierCompany)
        {
            SenderName = senderName;
            RecipientName = recipientName;
            DestinationAddress = destinationAddress;
            ShipmentDate = shipmentDate;
            ExpectedDeliveryDate = expectedDeliveryDate;
            ShipmentWeight = shipmentWeight;
            ShippingCost = shippingCost;
            Status = status;
            TrackingNumber = trackingNumber;
            CourierCompany = courierCompany;
        }
    }
}
