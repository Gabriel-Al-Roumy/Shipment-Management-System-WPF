﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using ShipmentManagementSystem.Data;
using ShipmentManagementSystem.Models;
using ShipmentManagementSystem.Models.Enums;

namespace ShipmentManagementSystem.Views
{
    public partial class AddShipmentWindow : Window
    {
        private readonly AppDbContext _context;

        public AddShipmentWindow()
        {
            InitializeComponent();
            _context = new AppDbContext(); // Initialize DbContext
        }

        private void SaveShipment(object sender, RoutedEventArgs e)
        {
            if (!ValidateInputs())
                return;
            ShipmentStatus selectedStatus = ShipmentStatus.Pending;  // Default value
            if (cmbStatus.SelectedItem != null)
            {
                string selectedStatusText = (cmbStatus.SelectedItem as ComboBoxItem)?.Content.ToString();
                selectedStatus = selectedStatusText switch
                {
                    "Shipped" => ShipmentStatus.Shipped,
                    "Delivered" => ShipmentStatus.Delivered,
                    _ => ShipmentStatus.Pending,  // Default to Pending if no match
                };
            }

            try
            {
                var shipment = new Shipment
                {
                    SenderName = txtSenderName.Text,
                    RecipientName = txtRecipientName.Text,
                    DestinationAddress = new Address
                    {
                        Street = txtStreet.Text,
                        City = txtCity.Text,
                        ZipCode = txtZipCode.Text,
                        Country = txtCountry.Text
                    },
                    ShipmentDate = dpShipmentDate.SelectedDate.GetValueOrDefault(),
                    ExpectedDeliveryDate = dpExpectedDeliveryDate.SelectedDate.GetValueOrDefault(),
                    ShipmentWeight = decimal.Parse(txtShipmentWeight.Text),
                    ShippingCost = decimal.Parse(txtShippingCost.Text),
                    TrackingNumber = txtTrackingNumber.Text,
                    CourierCompany = txtCourierCompany.Text,
                    Status = selectedStatus,
                };

                _context.Shipments.Add(shipment);
                _context.SaveChanges();

                MessageBox.Show("Shipment added successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private bool ValidateInputs()
        {
            if (string.IsNullOrWhiteSpace(txtSenderName.Text)) return ShowValidationError("Sender name is required.");
            if (string.IsNullOrWhiteSpace(txtRecipientName.Text)) return ShowValidationError("Recipient name is required.");
            if (string.IsNullOrWhiteSpace(txtStreet.Text)) return ShowValidationError("Street is required.");
            if (string.IsNullOrWhiteSpace(txtCity.Text)) return ShowValidationError("City is required.");
            if (string.IsNullOrWhiteSpace(txtZipCode.Text) || txtZipCode.Text.Length < 5) return ShowValidationError("Please enter a valid Zip Code, must be longer than 5 characters.");
            if (string.IsNullOrWhiteSpace(txtCountry.Text)) return ShowValidationError("Country is required.");
            if (!dpShipmentDate.SelectedDate.HasValue) return ShowValidationError("Shipment date is required.");
            if (!dpExpectedDeliveryDate.SelectedDate.HasValue) return ShowValidationError("Expected delivery date is required.");
            if (!decimal.TryParse(txtShipmentWeight.Text, out _)) return ShowValidationError("Please enter a valid shipment weight.");
            if (!decimal.TryParse(txtShippingCost.Text, out _)) return ShowValidationError("Please enter a valid shipping cost.");
            if (string.IsNullOrWhiteSpace(txtTrackingNumber.Text)) return ShowValidationError("Tracking number is required.");
            if (string.IsNullOrWhiteSpace(txtCourierCompany.Text)) return ShowValidationError("Courier company is required.");
            if (cmbStatus.SelectedItem == null) return ShowValidationError("Please select a shipment status.");
            return true;
        }

        private bool ShowValidationError(string message)
        {
            MessageBox.Show(message, "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
            return false;
        }

        private void BackToShipmentList(object sender, RoutedEventArgs e)
        {
            var shipmentListWindow = new ShipmentListWindow();
            shipmentListWindow.Show();
            this.Close();
        }
    }
}
