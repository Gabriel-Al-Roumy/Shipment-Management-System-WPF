﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ShipmentManagementSystem.Data;
using ShipmentManagementSystem.Models.Enums;
using ShipmentManagementSystem.Models;

namespace ShipmentManagementSystem.Views
{
    public partial class UpdateShipmentWindow : Window
    {
        private Shipment selectedShipment;

        public UpdateShipmentWindow(Shipment shipment)
        {
            InitializeComponent();
            selectedShipment = shipment;
            PopulateForm();
        }

        // Populate the form with the selected shipment data
        private void PopulateForm()
        {
            if (selectedShipment != null)
            {
                txtSenderName.Text = selectedShipment.SenderName;
                txtRecipientName.Text = selectedShipment.RecipientName;
                txtStreet.Text = selectedShipment.DestinationAddress.Street;
                txtCity.Text = selectedShipment.DestinationAddress.City;
                txtZipCode.Text = selectedShipment.DestinationAddress.ZipCode;
                txtCountry.Text = selectedShipment.DestinationAddress.Country;
                dpShipmentDate.SelectedDate = selectedShipment.ShipmentDate;
                dpExpectedDeliveryDate.SelectedDate = selectedShipment.ExpectedDeliveryDate;
                txtShipmentWeight.Text = selectedShipment.ShipmentWeight.ToString();
                txtShippingCost.Text = selectedShipment.ShippingCost.ToString();
                txtTrackingNumber.Text = selectedShipment.TrackingNumber;
                txtCourierCompany.Text = selectedShipment.CourierCompany;

                // Set the status
                cmbStatus.SelectedItem = cmbStatus.Items.Cast<ComboBoxItem>().FirstOrDefault(item => item.Content.ToString() == selectedShipment.Status.ToString());
            }
        }

        // Save the changes to the database
        private void SaveChanges(object sender, RoutedEventArgs e)
        {
            using (var context = new AppDbContext())
            {
                var shipmentToUpdate = context.Shipments
                                              .FirstOrDefault(s => s.ShipmentId == selectedShipment.ShipmentId);

                if (shipmentToUpdate != null)
                {
                    shipmentToUpdate.SenderName = txtSenderName.Text;
                    shipmentToUpdate.RecipientName = txtRecipientName.Text;
                    shipmentToUpdate.DestinationAddress.Street = txtStreet.Text;
                    shipmentToUpdate.DestinationAddress.City = txtCity.Text;
                    shipmentToUpdate.DestinationAddress.ZipCode = txtZipCode.Text;
                    shipmentToUpdate.DestinationAddress.Country = txtCountry.Text;
                    shipmentToUpdate.ShipmentDate = dpShipmentDate.SelectedDate.Value;
                    shipmentToUpdate.ExpectedDeliveryDate = dpExpectedDeliveryDate.SelectedDate.Value;
                    shipmentToUpdate.ShipmentWeight = decimal.Parse(txtShipmentWeight.Text);
                    shipmentToUpdate.ShippingCost = decimal.Parse(txtShippingCost.Text);
                    shipmentToUpdate.TrackingNumber = txtTrackingNumber.Text;
                    shipmentToUpdate.CourierCompany = txtCourierCompany.Text;
                    shipmentToUpdate.Status = (ShipmentStatus)Enum.Parse(typeof(ShipmentStatus), ((ComboBoxItem)cmbStatus.SelectedItem).Content.ToString());

                    context.SaveChanges(); // Save changes to the database
                }
            }

            MessageBox.Show("Shipment updated successfully!");
            
        }

        // Go back to the Shipment List window
        private void BackToShipmentList(object sender, RoutedEventArgs e)
        {
            var shipmentListWindow = new ShipmentListWindow();
            shipmentListWindow.Show();
            this.Close();
        }
    }
}
