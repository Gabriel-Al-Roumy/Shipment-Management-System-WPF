﻿using System.Configuration;
using System.Data;
using System.Windows;
using ShipmentManagementSystem.Data;

namespace ShipmentManagementSystem
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {

    }

}
