﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using ShipmentManagementSystem.Data; // Your DbContext namespace
using ShipmentManagementSystem.Models;
using ShipmentManagementSystem.Models.Enums;

namespace ShipmentManagementSystem.Views
{
    public partial class ShipmentListWindow : Window
    {
        private List<Shipment> allShipments; // Stores all shipments from DB

        public ShipmentListWindow()
        {
            InitializeComponent();
            LoadShipments();
        }

        private void LoadShipments()
        {
            using (var context = new AppDbContext()) 
            {
                allShipments = context.Shipments.ToList(); // Load shipments from database
            }

            lvShipments.ItemsSource = allShipments;
        }

        private void FilterShipments(object sender, RoutedEventArgs e)
        {
            string senderFilter = txtSender.Text.ToLower();
            string recipientFilter = txtRecipient.Text.ToLower();
            string statusFilter = (cmbStatus.SelectedItem as ComboBoxItem)?.Content.ToString();
            DateTime? shipmentDateFilter = dpShipmentDate.SelectedDate;

            var filteredShipments = allShipments.Where(s =>
                (string.IsNullOrEmpty(senderFilter) || s.SenderName.ToLower().Contains(senderFilter)) &&
                (string.IsNullOrEmpty(recipientFilter) || s.RecipientName.ToLower().Contains(recipientFilter)) &&
                (statusFilter == "All" || s.Status.ToString() == statusFilter) &&
                (!shipmentDateFilter.HasValue || s.ShipmentDate.Date == shipmentDateFilter.Value.Date)
            ).ToList();

            lvShipments.ItemsSource = filteredShipments;
        }

        private void ClearFilters(object sender, RoutedEventArgs e)
        {
            txtSender.Text = "";
            txtRecipient.Text = "";
            cmbStatus.SelectedIndex = 0;
            dpShipmentDate.SelectedDate = null;

            // Reset the ListView selection
            lvShipments.SelectedItem = null;

            // Reset list (assuming 'allShipments' contains the full list of shipments)
            lvShipments.ItemsSource = allShipments;
        }


        private void lvShipments_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selectedShipment = lvShipments.SelectedItem as Shipment;
            if (selectedShipment != null)
            {
                btnUpdate.IsEnabled = true;
                btnDelete.IsEnabled = true;
            }
            else
            {
                btnUpdate.IsEnabled = false;
                btnDelete.IsEnabled = false;
            }
        }
        private void ManageShipment(object sender, RoutedEventArgs e)
        {
            // Handle opening the Manage Shipment window
            MessageBox.Show("Manage Shipment button clicked!");
        }
        private void BackToMainWindow(object sender, RoutedEventArgs e)
        {
            var mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
        private void AddShipment(object sender, RoutedEventArgs e)
        {
            var addWindow = new AddShipmentWindow(); // Create a new window to add shipment
            addWindow.Show();
            this.Close();
        }

        private void DeleteShipment(object sender, RoutedEventArgs e)
        {
            var selectedShipment = lvShipments.SelectedItem as Shipment;
            if (selectedShipment != null)
            {
                using (var context = new AppDbContext())
                {
                    context.Shipments.Remove(selectedShipment);
                    context.SaveChanges();
                }
                LoadShipments(); // Refresh the list after deletion
            }
        }
            private void UpdateShipment(object sender, RoutedEventArgs e)
        {
            if (lvShipments.SelectedItem != null)
            {
                var selectedShipment = lvShipments.SelectedItem as Shipment;
                var updateShipmentWindow = new UpdateShipmentWindow(selectedShipment);
                updateShipmentWindow.Show();
                this.Close();
                
            }
        }


    }
}
